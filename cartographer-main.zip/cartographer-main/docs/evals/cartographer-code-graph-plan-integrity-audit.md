# Cartographer Code Graph Plan Integrity Audit

Status: smoke, recorded Codex, and live Codex evals audited
Date: 2026-05-12

## Synthesis

The Cartographer eval plan is now partially executable eval evidence.

The plan is scoped to the standalone Cartographer repo. It is grounded in a real read-only ARK target run, includes graph-speed and navigation evidence, separates deterministic graph facts from semantic overlay guidance, and names the Goodhart traps. The deterministic smoke runner now writes append-only JSON reports. The single most important remaining gap is the repeatable live Codex/adoption profile.

This audit covers the deterministic smoke runner and does not claim completion for:

- fixture snapshots
- judge prompts or calibration labels
- live Codex baseline-vs-graph distributions

## Current Repository Evidence

- branch: `main`
- remote status: `main...origin/main`
- latest commits:
  - `479e8b6 feat: report compact context omissions`
  - `0126cff fix: focus compact cartographer validation commands`
  - `9f31212 docs: refresh cartographer eval audit`
  - `149581a feat: add standalone cartographer graph cli`

Current package scripts include Cartographer graph commands, normal checks, and deterministic eval entrypoints:

- `cartographer`
- `cartographer:index`
- `cartographer:update`
- `cartographer:view`
- `cartographer:slice`
- `cartographer:impact`
- `cartographer:context`
- `cartographer:preflight`
- `cartographer:adoption`
- `cartographer:annotate`
- `cartographer:annotations`
- `eval:cartographer`
- `eval:cartographer:smoke`
- `eval:cartographer:baseline`
- `eval:cartographer:codex`
- `eval:cartographer:codex:live`
- `typecheck`
- `test`

Current report state:

- `docs/reports/cartographer-code-graph-smoke-2026-05-12T00-18-52-454Z.json` exists
- `docs/reports/cartographer-code-graph-codex-2026-05-12T00-22-58-653Z.json` exists and records the first failed codex runner attempt
- `docs/reports/cartographer-code-graph-codex-2026-05-12T00-23-23-289Z.json` exists
- `docs/reports/cartographer-code-graph-codex-live-2026-05-12T00-27-41-445Z.json` exists and records the first passed live codex run before stable check IDs were added
- `docs/reports/cartographer-code-graph-codex-live-2026-05-12T00-28-27-531Z.json` exists
- `scripts/cartographer-code-graph-evals.ts` exists
- the latest smoke report passed with 3 suites and 0 failures
- the latest recorded Codex trace report passed with 4 suites and 0 failures
- the latest live Codex report passed with 4 suites and 0 failures

## Read-Only ARK Target Evidence

The standalone CLI was run against `/Users/saint/dev/agent-runtime-kernel` with output under `/tmp`, not inside ARK.

Index evidence:

- command: `bun run cartographer:index -- --root /Users/saint/dev/agent-runtime-kernel --out /tmp/cartographer-ark-codegraph --max-file-bytes 500000`
- graph: 669 files, 4,620 nodes, 10,049 edges, 0 findings
- edge highlights: 835 `TESTS`, 2,000 `IMPORTS`, 1,177 `TYPE_IMPORTS`, 1,351 `EXPORTS`, 111 `USES_ENV`, 37 `TABLE_REFERENCES_TABLE`
- timing: 0.41s wall, 227,573,760 bytes max RSS

Preflight evidence:

- command: `bun run cartographer:preflight -- --root /Users/saint/dev/agent-runtime-kernel --live --path src/code-graph/commands.ts --out /tmp/cartographer-ark-codegraph --json`
- duration: 335ms
- graph load: 321ms
- context build: 13ms
- prompt render: 1ms
- primary paths: 17
- test paths: 2
- compact validation commands: 11
- validation command limit: 20
- omitted validation commands: 103
- findings: 0
- first validation commands:
  - `bun test ./src/code-graph/__tests__/builder.test.ts`
  - `bun test ./src/code-graph/__tests__/commands.test.ts`
  - `bun test ./src/code-graph`

## Score

Pass: 27
Fail: 3
N/A: 5

The remaining failures are specific to live agent and judge layers. They become invalidators if Cartographer claims baseline-vs-graph quality lift or semantic-overlay usefulness before the Codex profile, calibration data, and agreement reports exist.

## Structural Checks

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 1 | Suite has a written plan before code | pass | `docs/evals/cartographer-code-graph-eval-suites.md` exists and remains plan-first. |
| 2 | Report shape matches the required schema | pass | `docs/reports/cartographer-code-graph-smoke-2026-05-12T00-18-52-454Z.json` contains run metadata, environment, research grounding, suites, checks, metrics, and failures. |
| 3 | Reports land in `docs/reports` | pass | The smoke runner wrote `docs/reports/cartographer-code-graph-smoke-2026-05-12T00-18-52-454Z.json`. |
| 4 | Run IDs encode profile and timestamp | pass | `cartographer-code-graph-smoke-2026-05-12T00-18-52-454Z` includes suite family, profile, date, time, and millisecond component. |
| 5 | Status vocabulary is fixed | pass | The runner uses `passed`, `failed`, `skipped`, and `informational`. |
| 6 | Package scripts exist for smoke and baseline | pass | `package.json` includes `eval:cartographer`, `eval:cartographer:smoke`, and `eval:cartographer:baseline`. |

## Tier 1 Deterministic Checks

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 7 | Tier 1 exists and does cheap checks | pass | The smoke runner checks self and ARK graph contracts plus ARK preflight navigation in under 1 second on the recorded run. |
| 8 | Zero LLM calls in Tier 1 | pass | The proposed smoke profile explicitly excludes live model calls. |
| 9 | Tier 1 failures block before Tier 2 | pass | The runner exits non-zero when aggregate status is `failed`; no Tier 2 judge/live profile is run by default. |
| 10 | Graph modes are explicit | pass | Docs distinguish live, persisted, and fixture modes; ARK target evidence records live mode and `/tmp` output. |
| 11 | Compact output records limits and omissions | pass | `GraphContextCompact.limits.validationCommands` and `GraphContextCompact.omissions.validationCommands` are implemented and tested; ARK preflight reports a 20-command cap and 103 omitted validation commands. |

## Tier 2 Judge Checks

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 12 | Rubric is binary decomposed | pass | Semantic overlay criteria are binary in the plan, not a 1-5 quality score. |
| 13 | Judge uses a different model family | pass | Judge requirements state a different model family from the annotator. |
| 14 | Judge output is structured JSON | pass | Judge requirements state structured JSON with validation. |
| 15 | Full trace is passed to judge where trajectory matters | pass | Agent-harness scoring is planned around raw trace evidence, not final-only answers. |
| 16 | Pairwise comparisons swap order and average | n/a | The current semantic-overlay plan is not pairwise. |
| 17 | Calibration gold set exists | fail | No gold labels or calibration records exist. |
| 18 | Judge-human agreement is documented above threshold | fail | No judge prompt, calibration run, Cohen's kappa, or agreement report exists. |

## Tier 3 Human Review

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 19 | Human review cadence exists | fail | Calibration and human review are deferred. |
| 20 | New failures feed back into Tier 1 or Tier 2 | pass | Smoke report failures are normalized as `suite/check: summary` strings and surfaced in the top-level `failures` array. |

## Integrity Checks

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 21 | No easier flag is used for safety or scale claims | pass | The plan separates deterministic smoke, baseline, and opt-in live Codex profiles. |
| 22 | Mandatory live suites are not silently skipped | n/a | Live Codex is explicitly opt-in. |
| 23 | Safety checks are not downgraded to informational | pass | Hallucinated paths and graph-mandated violations are planned failures. |
| 24 | Sample counts and concurrency match documented defaults | pass | The runner does not exist, so no implementation can weaken them yet. |
| 25 | Image changes are scoped in the claim | n/a | The suite is local graph/navigation first, not container-image performance. |
| 26 | Reports are not manually edited | pass | The checked-in smoke report was generated by `bun run eval:cartographer:smoke`; reports should remain append-only receipts. |
| 27 | Failed, slow, and retried samples are recorded | pass | The plan requires failed, slow, and retried evidence to be recorded. |
| 28 | Production code does not special-case eval labels or run IDs | pass | Current production code has no `eval:cartographer` runner labels or report-path special cases. |
| 29 | Claims do not rely on stubbed provider metrics | pass | Current claims are local CLI/manual ARK target evidence only. |

## Lifecycle Checks

| # | Check | Status | Evidence |
| --- | --- | --- | --- |
| 30 | Pass rate is not saturated at 100% | n/a | Two smoke reports and two recorded Codex reports exist; the sample is still too small for saturation analysis. |
| 31 | Suite changes over time | pass | The plan/audit docs changed as standalone CLI and ARK target evidence landed. |
| 32 | Single-signal optimization risk is addressed | pass | The plan scores recall, precision, hallucinated paths, slice size, adoption, validation recall, omissions, and timings together. |

## Future Expansion Findings

- Future gap: baseline profile semantics are still shallow; `eval:cartographer:baseline` currently runs the deterministic contract profile rather than a richer fixture baseline comparison.
- Future gap: semantic-overlay usefulness remains unsupported until gold labels, judge prompts, and agreement metrics exist.

## Anti-Pattern Findings

- No mock-echo eval pattern found in the plan.
- No numeric 1-5 rubric found for semantic overlay scoring.
- No same-family judge usage is planned.
- No trace-opaque scoring is planned.
- No single-signal edge-count-only optimization is planned.

## Current Gate

The deterministic smoke, recorded Codex trace, and explicit live Codex gates have moved from planning to implementation.

The next gate is claim strength: do not claim graph-first Codex quality lift until repeated comparable live reports exist across task distributions.
